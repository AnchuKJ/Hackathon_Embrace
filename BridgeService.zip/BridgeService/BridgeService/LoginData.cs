﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BridgeService
{
    public class LoginData
    {
        public string LoginId { get; set; }
        public string Password { get; set; }
        public int ID { get; set; }
        public int UserType { get; set; }
    }
}