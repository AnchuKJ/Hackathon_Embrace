﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using RevealersAPI.DataAccess;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RevealersAPI.Model;
using RevealersAPI.Services;

namespace RevealersAPI.Controllers
{
    [Route("/")]
    [ApiController]
    public class SmartParkController : ControllerBase
    {
        SmartParkService parkViewService { get; set; }
        public SmartParkController(MongoDbservice dbService)
        {
            parkViewService = new SmartParkService(dbService);
        }       

        [HttpPost]
        [Route("park/home/UpdateSlot")]
        public async void UpdateSlot(ParkViewModel slotData)
        {
            await parkViewService.UpdateSlot(slotData);
        }

        [HttpPost]
        [Route("park/home/AddNewSlot")]
        public async void AddNewSlot(ParkViewModel slotData)
        {
            await parkViewService.AddNewSlot(slotData);
        }

        [HttpGet]
        [Route("park/home/GetAllSlots")]
        public async Task<ActionResult> GetAllSlots()
        {
            return await parkViewService.GetAllSlots();
        }

        [HttpGet]
        [Route("park/home/GetFullSlots")]
        public ActionResult GetFullSlots()
        {
            return parkViewService.GetFullSlots();
        }

        [HttpPost]
        [Route("park/home/GetSectionData")]
        public async Task<ActionResult> GetSectionData(SectionModel sectionData)
        {
            return await parkViewService.GetSectionData(sectionData.section);
        }

        [HttpPost]
        [Route("park/home/GetSlotStatus")]
        public async Task<int> GetSlotStatus(ParkViewModel slotData)
        {
            return await parkViewService.GetSlotStatus(slotData);
        }
    }
}