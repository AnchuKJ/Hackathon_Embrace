﻿using RevealersAPI.DataAccess;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using RevealersAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RevealersAPI.Services
{
    public class SmartParkService
    {
        private MongoDbservice _dbService;
        public SmartParkService(MongoDbservice dbAccess)
        {
            _dbService = dbAccess;
        }

        public async Task<OkResult> UpdateSlot(ParkViewModel slotData)
        {
            if (slotData.Status == 0)
            {
                slotData.Status = 1;
            }
            else if (slotData.Status == 1)
            {
                slotData.Status = 0;
            }
            var filter = Builders<ParkViewModel>.Filter.Where(x => x.SlotNo.Equals(slotData.SlotNo) && x.CameraNo.Equals(slotData.CameraNo));
            var update = Builders<ParkViewModel>.Update.Set(x => x.Status, slotData.Status);
            await _dbService.GetParkViewCollection().UpdateOneAsync(filter, update);
          
            return new OkResult();
        }

        public async Task<ActionResult> GetAllSlots()
        {
            var slotList = await _dbService.GetParkViewCollection().FindAsync(x => x.Status.Equals(0));            
            return new OkObjectResult(slotList.ToList());
        }

        public ActionResult GetFullSlots()
        {
            var slotList =  _dbService.GetParkViewCollection().AsQueryable();
            return new OkObjectResult(slotList.ToList());
        }


        public async Task<ActionResult> AddNewSlot(ParkViewModel slotData)
        {
            if (slotData != null)
            {
                var filter = Builders<ParkViewModel>.Filter.Where(x => x.SlotNo.Equals(slotData.SlotNo) && slotData.CameraNo.Equals(slotData.CameraNo));
                var slotList = (await _dbService.GetParkViewCollection().FindAsync(filter)).FirstOrDefault();
                if(slotList == null)
                {
                    await _dbService.GetParkViewCollection().InsertOneAsync(slotData);
                }
                return new OkResult();
            }
            return null;
        }

        public async Task<ActionResult> GetSectionData(string sectionName)
        {
            var sectionData = await _dbService.GetSectionCollection().FindAsync(x => x.section.Equals(sectionName));
            return new OkObjectResult(sectionData.FirstOrDefault());
        }

        public async Task<int> GetSlotStatus(ParkViewModel slotData)
        {
            var slotList = (await _dbService.GetParkViewCollection().FindAsync(x => x.SlotNo.Equals(slotData.SlotNo) & x.CameraNo.Equals(slotData.CameraNo))).FirstOrDefault();
            if(slotList != null)
            {
                return slotList.Status;
            }
            return 0;
        }

    }
}
