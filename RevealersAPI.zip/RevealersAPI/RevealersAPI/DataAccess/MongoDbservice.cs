﻿using MongoDB.Driver;
using RevealersAPI.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RevealersAPI.DataAccess
{
    public class MongoDbservice
    {
        private IMongoDatabase mongoDBClient;
		//private IMongoCollection<UserRegistrationModel> _registrationCollection;

		public MongoDbservice()
		{
			try
			{
				var datasource = "SmartPark";
				var mongoUrl = "mongodb://localhost:27017";
				MongoClientSettings settings = MongoClientSettings.FromUrl(new MongoUrl(mongoUrl));
				MongoClient client = new MongoClient(settings);
				mongoDBClient = client.GetDatabase(datasource);
			}
			catch { }
		}

		public IMongoDatabase GetMongoClient()
		{
			return mongoDBClient;
		}
		private string _parkCollectionName = "ParkView";
		private string _sectionCollectionName = "SectionView";
		private IMongoCollection<ParkViewModel> _parkCollection;
		private IMongoCollection<SectionModel> _sectionCollection;

		public IMongoCollection<ParkViewModel> GetParkViewCollection()
		{
			if (_parkCollection == null)
			{
				_parkCollection = mongoDBClient.GetCollection<ParkViewModel>(_parkCollectionName);
			}

			return _parkCollection;
		}
		public IMongoCollection<SectionModel> GetSectionCollection()
		{
			if (_sectionCollection == null)
			{
				_sectionCollection = mongoDBClient.GetCollection<SectionModel>(_sectionCollectionName);
			}

			return _sectionCollection;
		}

	}
}
