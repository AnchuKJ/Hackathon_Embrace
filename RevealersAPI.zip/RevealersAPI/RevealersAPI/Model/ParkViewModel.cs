﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RevealersAPI.Model
{
    public class ParkViewModel
    {
        public int SlotNo { get; set; }
        public int Status { get; set; }
        public string Building { get; set; }
        public string Section { get; set; }
        public int CameraNo { get; set; }
        public int IsRestricted { get; set; }
    }
}
