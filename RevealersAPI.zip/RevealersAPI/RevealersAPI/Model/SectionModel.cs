﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RevealersAPI.Model
{
    public class SectionModel
    {
        public string section { get; set; }
        public string imageUrl { get; set; }
    }
}
